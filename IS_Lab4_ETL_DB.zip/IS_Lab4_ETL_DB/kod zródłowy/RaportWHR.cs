﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IS_Lab4_ETL_DB
{
    internal class RaportWHR
    {
        public string Name { get; set; }

        public float FreedomOfChoices { get; set; }

        public float GDPperCapita { get; set; }

        public float LadderScore { get; set; }
    }
}
