﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace IS_Lab4_ETL_DB
{
    class dbconnection
    {
        public List<DataCustomWorld> RunAndExecute(decimal SurfaceMin, decimal FreedomOfChoiseMin,
            decimal LadderScoreMin, decimal PopulationMin, decimal GDPperCapitalMin)
        {
            string connectionString = "" +
                "datasource=127.0.0.1;" + // adres domyślny dla
                "port=3306;" + // domyślny port
                "username=root;" + // domyślna nazwa użytkownika który ma dostęp do bazy danych
                "password=;" + // hasło dostępowe
                "SslMode = none;"; // tryb połączenia SSL
                                   //"database=world;" // nazwa bazy danych do które siępodłączamy;

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase;
            MySqlDataReader reader;
            List<DataWorld> dw_list = new List<DataWorld>();
            List<RaportWHR> whr_list = new List<RaportWHR>();
            List<DataCustomWorld> dcw_list = new List<DataCustomWorld>();

            try
            {
                // nawiązanie połączenia z bazą danych
                databaseConnection.Close();
                databaseConnection.Open();

                // <POBIERANIE DANYCH>
                try
                {
                    string query1 = $"SELECT * FROM world.country WHERE SurfaceArea >= {SurfaceMin.ToString().Replace(',', '.')}" +
                        $" AND Population >= {PopulationMin.ToString().Replace(',', '.')}";
                    commandDatabase = new MySqlCommand(query1, databaseConnection);
                    commandDatabase.CommandTimeout = 60;
                    reader = commandDatabase.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            dw_list.Add(new DataWorld()
                            {
                                Code = reader.GetString(0),
                                Name = reader.GetString(1),
                                SurfaceArea = float.Parse(reader.GetString(4)),
                                Population = int.Parse(reader.GetString(6))
                            });
                        }
                    }
                    // jeśli zapytanie nie zwróciło wartości
                    else { }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                // </POBIERANIE DANYCH>
                try
                {
                    string query1 = $"SELECT * FROM whr.raport WHERE FreedomToMakeLifeChoices >= {FreedomOfChoiseMin.ToString().Replace(',', '.')} " +
                        $"AND LoggedGDPPerCapital >= {GDPperCapitalMin.ToString().Replace(',', '.')} AND LadderScore >= {LadderScoreMin.ToString().Replace(',', '.')}";
                    commandDatabase = new MySqlCommand(query1, databaseConnection);
                    commandDatabase.CommandTimeout = 60;
                    reader = commandDatabase.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            whr_list.Add(new RaportWHR()
                            {
                                Name = reader.GetString(0),
                                FreedomOfChoices = float.Parse(reader.GetString(9)),
                                GDPperCapita = float.Parse(reader.GetString(6)),
                                LadderScore = float.Parse(reader.GetString(2))
                            });
                        }
                    }
                    // jeśli zapytanie nie zwróciło wartości
                    else { }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                // <PRZETWARZANIE DANYCH>

                foreach (var dw in dw_list)
                {
                    foreach (var whr in whr_list)
                    {
                        if (dw.Name == whr.Name)
                        {
                            dcw_list.Add(new DataCustomWorld()
                            {
                                Name = dw.Name,
                                Code = dw.Code,
                                SurfaceArea = dw.SurfaceArea,
                                Population = dw.Population,
                                FreedomOfChoices = whr.FreedomOfChoices,
                                GDPperCapita = whr.GDPperCapita,
                                LadderScore = whr.LadderScore,
                            });
                        }
                    }
                }


                // </PRZETWARZANIE DANYCH>
                StringBuilder sCommand = new StringBuilder();
                sCommand.Append("DELETE FROM custom_world.countries; ");
                sCommand.Append("INSERT INTO custom_world.countries VALUES");
                List<string> Rows = new List<string>();
                foreach (var z in dcw_list)
                {
                    Rows.Add(
                    string.Format("('{0}','{1}','{2}','{3}','{4}','{5}','{6}')",
                    z.Code,
                    z.Name,
                    z.SurfaceArea,
                    z.Population,
                    z.FreedomOfChoices.ToString().Replace(",", "."),
                    z.GDPperCapita.ToString().Replace(",", "."),
                    z.LadderScore.ToString().Replace(",", ".")
                    ));
                }
                sCommand.Append(string.Join(",", Rows));
                sCommand.Append(";");

                string query3 = sCommand.ToString();
                commandDatabase = new MySqlCommand(query3, databaseConnection);
                commandDatabase.ExecuteNonQuery();


                // zamknięcie połączenia z bazą danych
                databaseConnection.Close();
            }
            // jeśli nie udało się nawiązać połączenia ...
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dcw_list;
        }

    }
}

