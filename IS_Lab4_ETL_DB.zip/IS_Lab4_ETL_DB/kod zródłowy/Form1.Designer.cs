﻿
namespace IS_Lab4_ETL_DB
{
    partial class Form1
    {
 
        private System.ComponentModel.IContainer components = null;

     
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LadderScore = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.param_SurfaceArea = new System.Windows.Forms.NumericUpDown();
            this.param_Freedom = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.param_LadderScore = new System.Windows.Forms.NumericUpDown();
            this.param_Population = new System.Windows.Forms.NumericUpDown();
            this.param_GDPperCapital = new System.Windows.Forms.NumericUpDown();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.param_SurfaceArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_Freedom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_LadderScore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_Population)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_GDPperCapital)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(487, 68);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 22);
            this.button1.TabIndex = 0;
            this.button1.Text = "Kompiluj";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "SurfaceArea";
            // 
            // LadderScore
            // 
            this.LadderScore.AutoSize = true;
            this.LadderScore.Location = new System.Drawing.Point(335, 39);
            this.LadderScore.Name = "LadderScore";
            this.LadderScore.Size = new System.Drawing.Size(72, 15);
            this.LadderScore.TabIndex = 3;
            this.LadderScore.Text = "LadderScore";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Population";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(335, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "GDPperCapital";
            // 
            // param_SurfaceArea
            // 
            this.param_SurfaceArea.DecimalPlaces = 3;
            this.param_SurfaceArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.param_SurfaceArea.Location = new System.Drawing.Point(134, 7);
            this.param_SurfaceArea.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.param_SurfaceArea.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.param_SurfaceArea.Name = "param_SurfaceArea";
            this.param_SurfaceArea.Size = new System.Drawing.Size(131, 23);
            this.param_SurfaceArea.TabIndex = 7;
            // 
            // param_Freedom
            // 
            this.param_Freedom.DecimalPlaces = 3;
            this.param_Freedom.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.param_Freedom.Location = new System.Drawing.Point(134, 70);
            this.param_Freedom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.param_Freedom.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.param_Freedom.Name = "param_Freedom";
            this.param_Freedom.Size = new System.Drawing.Size(131, 23);
            this.param_Freedom.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "FreedomOfChoise";
            // 
            // param_LadderScore
            // 
            this.param_LadderScore.DecimalPlaces = 3;
            this.param_LadderScore.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.param_LadderScore.Location = new System.Drawing.Point(438, 37);
            this.param_LadderScore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.param_LadderScore.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.param_LadderScore.Name = "param_LadderScore";
            this.param_LadderScore.Size = new System.Drawing.Size(131, 23);
            this.param_LadderScore.TabIndex = 10;
            // 
            // param_Population
            // 
            this.param_Population.DecimalPlaces = 3;
            this.param_Population.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.param_Population.Location = new System.Drawing.Point(134, 37);
            this.param_Population.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.param_Population.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.param_Population.Name = "param_Population";
            this.param_Population.Size = new System.Drawing.Size(131, 23);
            this.param_Population.TabIndex = 11;
            // 
            // param_GDPperCapital
            // 
            this.param_GDPperCapital.DecimalPlaces = 3;
            this.param_GDPperCapital.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.param_GDPperCapital.Location = new System.Drawing.Point(438, 7);
            this.param_GDPperCapital.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.param_GDPperCapital.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.param_GDPperCapital.Name = "param_GDPperCapital";
            this.param_GDPperCapital.Size = new System.Drawing.Size(131, 23);
            this.param_GDPperCapital.TabIndex = 12;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 97);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(1199, 434);
            this.dataGridView1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 542);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.param_GDPperCapital);
            this.Controls.Add(this.param_Population);
            this.Controls.Add(this.param_LadderScore);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.param_Freedom);
            this.Controls.Add(this.param_SurfaceArea);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LadderScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.param_SurfaceArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_Freedom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_LadderScore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_Population)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.param_GDPperCapital)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LadderScore;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown param_SurfaceArea;
        private System.Windows.Forms.NumericUpDown param_Freedom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown param_LadderScore;
        private System.Windows.Forms.NumericUpDown param_Population;
        private System.Windows.Forms.NumericUpDown param_GDPperCapital;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EventHandler label1_Click;
        private EventHandler label2_Click;
    }
}

