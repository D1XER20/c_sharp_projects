Windows 10pro x64
.Net v5.0
Google.Apis.Gmail.v1 
