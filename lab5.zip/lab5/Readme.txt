Windows 10 x64
IntelliJ IDEA 2021.2.3 (Ultimate Edition)
Visual Studio Community 2019
SoapUI x64 5.6.0