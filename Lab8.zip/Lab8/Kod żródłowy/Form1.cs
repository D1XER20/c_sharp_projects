﻿using System;
using Google.Apis.Gmail.v1;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private GmailService service;
        private string email;
        private List<Message> MessagesList;
        public Form1(GmailService service)
        {
            InitializeComponent();
            this.service = service;
            var result = service.Users.GetProfile("me").Execute();
            email = result.EmailAddress;
            MessagesList = new List<Message>();
            label1.Text = "E-mail list(" + result.MessagesTotal + ")";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Clear();
            var emailListRequest = service.Users.Messages.List(email);
            emailListRequest.IncludeSpamTrash = false;
            var emailListResponse = emailListRequest.Execute();

            if (emailListResponse != null && emailListResponse.Messages != null)
            {
                listView1.Columns.Add("From", 100);
                listView1.Columns.Add("Subject", 100);
                listView1.Columns.Add("Content", 500);
                listView1.View = View.Details;
                listView1.GridLines = true;
                listView1.FullRowSelect = true;
                foreach (var mail in emailListResponse.Messages)
                { 
                
                    string[] arr = new string[3];
                    ListViewItem item;
                    var message = service.Users.Messages.Get(email, mail.Id).Execute();

                    var m = new Message()
                    {
                        From = message.Payload.Headers.FirstOrDefault(x => x.Name == "From").Value,
                        Subject = message.Payload.Headers.FirstOrDefault(x => x.Name == "Subject").Value,
                        Content = message.Snippet
                    };

                    arr[0] = m.From;
                    arr[1] = m.Subject;
                    arr[2] = m.Content;
                    item = new ListViewItem(arr);
                    listView1.Items.Add(item);
                }
                
            } 
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                textBox1.Text = listView1.SelectedItems[0].SubItems[0].Text;
                textBox2.Text = listView1.SelectedItems[0].SubItems[1].Text;
                textBox3.Text = listView1.SelectedItems[0].SubItems[2].Text;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
