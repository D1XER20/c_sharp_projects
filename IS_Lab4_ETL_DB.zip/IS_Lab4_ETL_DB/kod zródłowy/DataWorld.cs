﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IS_Lab4_ETL_DB
{
    internal class DataWorld
    {
        public string Code { get; set; }

        public string Name { get; set; }

        public float SurfaceArea { get; set; }

        public int Population { get; set; }
    }
}
