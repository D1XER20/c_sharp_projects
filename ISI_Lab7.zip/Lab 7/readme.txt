Środowisko: Windows 10 Pro 64-bit
.NET 5
Postman v 9.5
