﻿using ServiceReference1;
using System;
using System.Threading.Tasks;

namespace IS_Lab5_SOAPCS
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("My First SOAP Client!");

            var client = new MyFirstSOAPInterfaceClient();

            var text = await client.getHelloWorldAsStringAsync("Jacek");

            var now = DateTime.Now;
            var nowButMonthForward = DateTime.Now.AddMonths(1);

            string dateFormat = "dd-MM-yyyy HH:mm";

            var text2 = await client.getDaysBetweenDatesAsync(
                now.ToString(dateFormat),
                nowButMonthForward.ToString(dateFormat)
            );

            Console.WriteLine(text);
            Console.WriteLine(text2);
        }
    }
}
