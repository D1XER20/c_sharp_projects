Windows 10 Pro x64
XAMPP Control Panel 7.4.30
PHPmyAdmin 5.2.0
.NET 6.0
MySQLData 8.0.31
Przy imporcie znak mędzy kolumnami - ;